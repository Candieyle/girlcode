#221047551 Lerato Motsabi
#220028568 Ketshepaone Moribe

from flask import Flask, render_template, request, jsonify, send_from_directory
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import os

app = Flask(__name__)

# Helper function to generate feedback based on test scores
def generate_feedback(scores):
    try:
        scores = [int(score) for score in scores.split(',')]
        average_score = sum(scores) / len(scores)

        if 0 <= average_score < 30:
            return "Your marks are not impressive; you need to improve."
        elif 30 <= average_score < 50:
            return "You need to work harder."
        elif 50 <= average_score < 70:
            return "Good, but moderate."
        elif 70 <= average_score <= 100:
            return "Excellent!"
        else:
            return "Invalid scores. Please check your input."
    except ValueError:
        return "Error processing scores. Ensure they are numbers separated by commas."

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit_data():
    try:
        student_id = request.form['student_id']
        test_scores = request.form['test_scores']
        study_time = request.form['study_time']
        engagement = request.form['engagement']
        difficulty = request.form['difficulty']

        # Generate feedback based on test scores
        score_feedback = generate_feedback(test_scores)

        strengths = "Excellent in problem-solving."
        improvements = "Needs to work on time management."
        recommendations = "Recommended: Youtube Videos and AI tools."

        return jsonify({
            "status": "success",
            "data": {
                "student_id": student_id,
                "test_scores": test_scores,
                "study_time": study_time,
                "engagement": engagement,
                "difficulty": difficulty,
                "score_feedback": score_feedback,
                "strengths": strengths,
                "improvements": improvements,
                "recommendations": recommendations
            }
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

@app.route('/download_feedback', methods=['POST'])
def download_feedback():
    try:
        student_id = request.form['student_id']
        test_scores = request.form['test_scores']
        study_time = request.form['study_time']
        engagement = request.form['engagement']
        difficulty = request.form['difficulty']

        # Generate feedback based on test scores
        score_feedback = generate_feedback(test_scores)

        # Feedback text
        feedback_data = """
        Student ID: {student_id}
        Test Scores: {test_scores}
        Study Time: {study_time} hours
        Engagement: {engagement}/10
        Difficulty: {difficulty}
        
        Feedback: {score_feedback}
        
        Strengths: Excellent in problem-solving.
        Improvements: Needs to work on time management.
        Recommendations: Recommended: Youtube Videos and AI tools.
        """

        # Generate PDF
        pdf_filename = "feedback_{student_id}.pdf"  # Corrected filename formatting
        pdf_path = os.path.join(os.getcwd(), pdf_filename)
        c = canvas.Canvas(pdf_path, pagesize=letter)
        c.setFont("Helvetica", 10)
        width, height = letter

        # Write feedback to PDF
        lines = feedback_data.split("\n")
        y_position = height - 40  # Start from the top of the page

        for line in lines:
            c.drawString(40, y_position, line)
            y_position -= 12  # Move down for the next line

            # Avoid drawing outside the page
            if y_position < 40:
                c.showPage()
                c.setFont("Helvetica", 10)
                y_position = height - 40

        c.save()

        return jsonify({
            "status": "success",
            "file_url": "/download/{pdf_filename}"  # Corrected file URL formatting
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

# Serve the generated PDF file for download
@app.route('/download/<filename>')
def download_file(filename):
    try:
        return send_from_directory(os.getcwd(), filename, as_attachment=True)
    except FileNotFoundError:
        return jsonify({"status": "error", "message": "File not found!"})

@app.route('/ask', methods=['POST'])
def ask_question():
    question = request.form.get('question', '')
    responses = {
        "What is AI?": "AI stands for Artificial Intelligence, which refers to the simulation of human intelligence by machines.",
        "How do I improve my grades?": "To improve your grades, focus on time management, review materials regularly, and seek help when needed.",
        "What resources are available?": "We recommend online platforms like Khan Academy, Coursera, and advanced textbooks."
    }
    response = responses.get(question, "I'm sorry, I don't have an answer for that right now.")
    return jsonify({"status": "success", "response": response})

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        message = request.form.get('message', '').strip()

        if not all([name, email, message]):
            return jsonify({"status": "error", "message": "Please fill in all fields"}), 400

        return jsonify({"status": "success", "message": "Thank you, {name}! Your message has been received."})

    return render_template('contact.html') 

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/analysis')
def analysis():
    return render_template('analysis.html')

if __name__ == '__main__':
    app.run(debug=True)